//
//  ViewController.h
//  PlaySound
//
//  Created by RENUKA on 29/06/15.
//  Copyright (c) 2015 RENUKA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>



@interface ViewController : UIViewController{
    
}

-(IBAction)Playme;

@end

