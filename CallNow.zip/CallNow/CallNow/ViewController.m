//
//  ViewController.m
//  CallNow
//
//  Created by Raghava on 6/28/15.
//  Copyright (c) 2015 Raghava. All rights reserved.
//

#import "ViewController.h"
@import AddressBook;

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self perform];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)perform
{
  /*  ABAddressBook *AB = [ABAddressBook sharedAddressBook];
    ABSearchElement *nameIsSmith =[ABPerson searchElementForProperty:kABLastNameProperty label:nil key:nil value:@"Smith"
    comparison:kABEqualCaseInsensitive];
    NSArray *peopleFound =[AB recordsMatchingSearchElement:nameIsSmith];
}
    */
 
    
  //  ABAddressBookCreateWithOptions(<#CFDictionaryRef options#>, <#CFErrorRef *error#>)
    
    
    ABAddressBookRef addressBook = ABAddressBookCreate();
   /* if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusDenied ||
        ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusRestricted){
        //1
        NSLog(@"Denied");
    } else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized){
        //2
        NSLog(@"Authorized");
    } else{ //ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined
        //3
        NSLog(@"Not determined");
    }*/
    ABAddressBookRequestAccessWithCompletion(ABAddressBookCreateWithOptions(NULL, nil), ^(bool granted, CFErrorRef errorCoding) {
        if (!granted){
            //4
            NSLog(@"Just denied");
            return;
        }
        //5
        NSLog(@"Just authorized");
    });
    
    NSString *full = @"Sweety USA";
    CFArrayRef contacts = ABAddressBookCopyPeopleWithName(addressBook, (__bridge CFStringRef)(full));
    NSLog(@"contacts %s",contacts);
    CFIndex nPeople = CFArrayGetCount(contacts);
    NSLog(@"npeople %ld",nPeople);
    
    if ((contacts != nil) && (CFArrayGetCount(contacts) > 0))
    {
        ABRecordRef person = CFArrayGetValueAtIndex(contacts, 0);
        ABPersonViewController *picker = [[[ABPersonViewController alloc] init] autorelease];
        picker.personViewDelegate = self;
        picker.displayedPerson = person;
        // Allow users to edit the person’s information
        picker.allowsEditing = YES;
        
        [self.navigationController pushViewController:picker animated:YES];
        NSMutableArray *phoneNumbers = [[[NSMutableArray alloc] init] autorelease];
        ABMultiValueRef multiPhones = ABRecordCopyValue(person,kABPersonPhoneProperty);
        for(CFIndex i=0;i<ABMultiValueGetCount(multiPhones);++i) {
            CFStringRef phoneNumberRef = ABMultiValueCopyValueAtIndex(multiPhones, i);
            NSString *phoneNumber = (NSString *) phoneNumberRef;
            
            [phoneNumbers addObject:phoneNumber];
            NSLog(@"phone number %@",phoneNumber);
            
            
            NSMutableString *strippedString = [NSMutableString
                                               stringWithCapacity:phoneNumber.length];
            
            NSScanner *scanner = [NSScanner scannerWithString:phoneNumber];
            NSCharacterSet *numbers = [NSCharacterSet
                                       characterSetWithCharactersInString:@"0123456789"];
            
            while ([scanner isAtEnd] == NO) {
                NSString *buffer;
                if ([scanner scanCharactersFromSet:numbers intoString:&buffer]) {
                    [strippedString appendString:buffer];
                    
                } else {
                    [scanner setScanLocation:([scanner scanLocation] + 1)];
                }
            }
            
            NSLog(@"%@", strippedString); // "123123123"
            
           // [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://%@",phoneNumber]];
            //[self callWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",phoneNumber]]];
        
           NSString *phoneCallNum = [NSString stringWithFormat:@"tel://%@",strippedString ];
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneCallNum]];
            
           
        }

            
        
        
    }
    else
    {
        // Show an alert if "Appleseed" is not in Contacts
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:@"Could not find Appleseed in the Contacts application"
                                                       delegate:nil
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    CFRelease(addressBook);
    CFRelease(contacts);

    
   /* if (nPeople)
    {
        NSMutableArray *rIds = [[NSMutableArray alloc] init];
        int numberOfContactsMatchingName = (int)CFArrayGetCount(contacts);
        if (numberOfContactsMatchingName>1)
        {
            for ( int i=0; i<numberOfContactsMatchingName; ++i)
            {
                
                ABRecordID thisId = ABRecordGetRecordID(CFArrayGetValueAtIndex(contacts, i));
                NSNumber *rid = [NSNumber numberWithInteger:thisId];
                //NSLOG(@"%dMatched, this ID = %@", numberOfContactsMatchingName, rid);
                [rIds addObject:rid];
            }
            
            
            for (int i=0; i<rIds.count; ++i)
            {
                //contactRecord = ABAddressBookGetPersonWithRecordID(addressBook, (ABRecordID)recId);
                ABRecordRef contactRecord;
                contactRecord = ABAddressBookGetPersonWithRecordID(addressBook, [rIds[i] integerValue]);
                if (contactRecord)
                {
                    NSLog(@" The contact is:%s",contactRecord);
                }
                else
                {
                    //NSLOG (@"Noone found with recordId %s");
                    NSLog(@"Came here");
                }
            }
        }
    }*/
    
    
    
    
    
}
+ (void)callWithURL:(NSURL *)url
{
    static UIWebView *webView = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        webView = [UIWebView new];
    });
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
}

@end
